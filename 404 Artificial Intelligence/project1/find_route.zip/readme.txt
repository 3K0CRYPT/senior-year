1. Michael Bartlet 10603355
2. C++
3. x64 Windows 10 (tested on Raspbian also)
4. A single file that contains all methods/members
5. To compile:
	The included Makefile should be sufficient, so simplying run "make" from terminal to compile to a binary.

	IF THE MAKEFILE FAILS: Using g++, run in a teriminal in the directory:
		g++ -std=c++14 find_route.cpp -o find_route

	To execute the resulting binary in terminal:
		./find_route.exe input1.txt Bremen Frankfurt

	*I've included an .exe. compiled on x64 Windows 10 if all else fails.