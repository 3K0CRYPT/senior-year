# Project 1

Your final submission must contain a README file with the following:
 * Your name.
 * A list of all the files in your submission and what each does.
 * Any unusual / interesting features in your programs.
 * Approximate number of hours you spent on the project.

Deliverable 1:

Completed by: Nicholas Zustak

Finished - shell builtins.

Deliverable 2:

Completed by: Nicholas Zustak

Finished - shell tab completions; works better for environment.