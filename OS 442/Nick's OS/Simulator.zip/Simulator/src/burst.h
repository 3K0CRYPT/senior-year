#include <stdlib.h>
#pragma once

enum burstType {CPU, IO};

struct burst {
	burstType type;
	int length;

	burst(enum burstType t, int l) {
		type = t;
		length = l;
	}
};