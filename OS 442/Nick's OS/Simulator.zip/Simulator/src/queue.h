#include <stdlib.h>
#pragma once

struct node {
    void *data;
    struct node *next, *previous;
};

struct queue {
    struct node *head, *tail;
};