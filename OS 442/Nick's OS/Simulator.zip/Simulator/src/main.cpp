#include <iostream>
#include "process.h"
#include "event.h"
#include "burst.h"
#include "thread.h"
#include <getopt.h>
//#include <string>
#pragma once

#define no_argument 0 // must be defined for getopt
#define required_argument 1 // ""
#define optional_argument 2 // ""

using namespace std;

void processArgs(int argc, char** argv);

int main(int argc, char* argv[]) {
  processArgs(argc, argv);

  return 0;
}

void processArgs(int argc, char* argv[]) {
  // Will use getopt to ensure proper number of flags are used, if at all
  // Sends errors / help screen if otherwise
  const char* const short_flag = "tva:h";
  char infilename[] = "\"";
  // option constructor (name, has_arg, flag, val), if flag ==0, then val is a unique int describing the option.
  // In this case, an int in the form of a char
  const option long_flag[] = {{"per_thread", no_argument, 0, 't'},
                              {"verbose", no_argument, 0, 'v'},
                              {"algorithm", no_argument, 0, 'a'},
                              {"help", no_argument, 0, 'h'},
                              {0,0,0,0}};
  int val = 0; // will get val from arguments;
  int opt = 0;
  while((opt = getopt_long(argc, argv, short_flag, long_flag, &val)) != -1) {
  	cout << "Getting arguments" << endl;
  	cout << "val is " << val << endl;

    if(val == -1) {
    	cout << "No arguments" << endl;
      // no arguments
      break;
    }
    switch(val) {
      case 't':
        printf("Flag t");
        cout << "Flag t" << endl;
      	strcpy(infilename, optarg);
      	printf(infilename);
        break;
      case 'v':
      	strcpy(infilename, optarg);
      	printf(infilename);
        break;
      case 'a':
      	strcpy(infilename, optarg);
      	printf(infilename);
        break;
      case 'h':
      	strcpy(infilename, optarg);
      	printf(infilename);
        break;
      default:
      	//strcpy(infilename, optarg);
      	// JUST PRINT THE HELP THING
      	cout << "Default case" << endl;
      	printf(infilename);
      	break;
    }
  }
  printf(infilename);
}
