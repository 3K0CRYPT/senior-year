#include "queue.h"
#pragma once

enum threadType {NEW, READY, RUNNING, BLOCKED, EXIT};
extern const char *const thread_states[];

struct thread {
	threadType current, last;
	// struct process parent_process;
	queue que;
	int offset;
	int timeSlice;
	int arrivalTime;
	int startTime;
	int endTime;
	int serviceTime;
	int cpuTime;
	int ioTime;
	int lastTime;
	int lastBlock;

	void setReady();
	void setRunning();
	void setBlocked();
	void setExit();

};