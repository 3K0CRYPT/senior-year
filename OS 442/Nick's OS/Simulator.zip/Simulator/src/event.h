#include <stdlib.h>
#include "queue.h"
#include "process.h"
#pragma once

enum eventType { 
				THREAD_ARRIVED,
				THREAD_DISPATCH_COMLPETED,
				PROCESS_DISPATCH_COMPLETED,
				CPU_BURST_COMPLETED,
				IO_BURST,COMPLETED,
				THREAD_COMPLETED,
				THREAD_PREEMPTED,
				DISPATCHER_INVOKED
				};

struct event {
	eventType type;
	int time;

	event(eventType ty, int t) {
		type = ty;
		time = t;
	}
};