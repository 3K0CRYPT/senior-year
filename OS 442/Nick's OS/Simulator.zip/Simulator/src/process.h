#include <stdlib.h>
#include "thread.h"
#pragma once

enum processType {SYSTEM, INTERACTIVE, NORMAL, BATCH}; // for prioritizing

struct process {
	processType type;
	int pid;
	int num_threads;
	struct thread *threads; // hold pointers instead of copies
};