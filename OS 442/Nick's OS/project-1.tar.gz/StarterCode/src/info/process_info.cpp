#include "process_info.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>

using namespace std;


ProcessInfo get_process(int pid, const char* basedir) {
  // TODO: implement me
  return ProcessInfo();
}


vector<ProcessInfo> get_all_processes(const char* basedir) {
  // TODO: implement me
  return vector<ProcessInfo>();
}
