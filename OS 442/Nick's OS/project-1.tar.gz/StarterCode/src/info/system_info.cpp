#include "system_info.h"
#include <cstdio>
#include <fstream>
#include <iostream>
#include <sstream>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>

using namespace std;


double get_uptime() {
  // TODO: implement me
  return 0.0;
}


SystemInfo get_system_info() {
  // TODO: implement me
  return SystemInfo();
}
