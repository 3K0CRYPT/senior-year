#include "cpu_info.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;


vector<CpuInfo> get_cpu_info() {
  // TODO: implement me
  return vector<CpuInfo>();
}


CpuInfo operator -(const CpuInfo& lhs, const CpuInfo& rhs) {
  // TODO: implement me
  return CpuInfo();
}
